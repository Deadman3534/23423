/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
/* находит сумму двух чисел
#include <iostream>

using namespace std;

int sum(int x, int y) // определение функции
{
 return x + y;   
}


int main() // главная функция
{
    int a =5 , b = 3, c;
    c= sum(a,b); // 1
    cout << "sum = " << c << endl;
    cout << "sum = " << sum (a,b) << endl; //2
    return 0;
}*/

/*
#include <iostream>

using namespace std;

float max(float x, float y); // объявление функции

int main() // главная функция
{
    float a = 5.5, b = 3.2, c = 14.1,d;
    d= max(max(a,b),c); // 1
    cout << "max = " << d << endl;
    return 0;
}

float max(float x , float y) // определение функции
{
    return (x>y) ? x:y;
}*/

/* переделать
#include <iostream>

using namespace std;

float min(float x, float y); 

int main() 
{
    float a,b,z;   
    cout << "Введите число" << endl;
    cin >> a,b,z;
    z= min(3*a ,2*b)+ min(a-b,a+b);
    cout << "min = " << z << endl;
    return 0;
}
 float min(float x , float y) 
{
    return (x > y) ? y:x;
}*/

// 12 пример
/*
#include <iostream>

using namespace std;

    int f(int x)
    {
        if(x >= 10 && x <= 99) return x % 10 * 10 + x / 10;
        return x;
    }
int main()
{
    printf("%d\n%d\n%d", f(15),f(1),f(101));
    return 0;
}*/

/*
#include <iostream>
using namespace std;

int a = 100, b = 20; // глобальные переменные a and b

void f1 (int a) //локальная переменная a
{
    a += 10; //изменяеться значение локальной переменной а
    cout << "f1:\t" << a << "\t" << ::a << endl; // На экран выводится значение локальной переменной а, 
    //и через обращение к области .. значение глобальной переменной а
}

void f2 (int b) // локальная переменная b
{
    b*=2; //  изменяеться значение локальной переменной b
    cout << "f2\t" << b << "\t" << a << endl; //На экран выводиться значение локальных пременных а и б
}

int main()
{
    cout << "main:\t" << a << "\t" << b << endl; //на экран выводится глобальных переменных а и б 
    f1(a); f2(b); //вызыв функций ф1 и ф2
    cout << "main:\t" << a << "\t" << b << endl; //на экран выводится глобальных переменных а и б
    return 0;
}*/













