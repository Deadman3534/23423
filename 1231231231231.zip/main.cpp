/*
#include <iostream>

using namespace std;

void f(int a, int *b, int &c)// определение функции f
{
    a += 10;
    (*b) +=10;
    c += 10;
    cout << "f:\t" << a << "\t" << *b << "\t" << c << endl;
}

int main()
{
    int x=10 , y=20, z = 30;
    cout<<"main:\t" << x << "\t" << y << "\t" << z << endl;
    f(x,&y,z); // вызов функции f
    cout << "main:\t" << x << "\t" << y << "\t" << z << endl;
    return 0;
}
*/

/*
#include <iostream>
using namespace std;
void f (const int *b, int &c)
{
    (*b) += 10; //попытка изменить констатный параметр
    c += 10;
}
 
 int main ()
 {
    int y = 20, z = 30;
    f(&y, 2); // константу нельзя переобразовать параметр, передаваемый по адресу.
    cout << "main:\t" << y << "\t" << z << endl;
    return 0;
 }
 */
 /*
#include <iostream>
using namespace std;
 int a; // 1 глобальная переменная a
 int main()
 {
    int b; // 2 локальная перменная b
    extern int x; // 3 переменная x  определена в другом месте
    static c; // 4 локальная статическая переменная c
    a = 1;// 5 присваивание глобальной переменной
    int a;// 6 локальная переменная a
    a = 2;// 7 присваивание локальной переменной
    ::a =3;// 8 присваивание глобальной переменной
    return 0;
 }   
int x =4; // 9 определение и инициализация x
 */
 /*
#include <iostream>
#include <cmath> 
using namespace std;
float volume (float r)
{
    const float pi = 3.14;
    return 4.0/3*pow(r,3);
}

int main ()
{
    float z, r1,r2,r3;
    cout << "введите радиус шара" << endl;
    cin >> r1 >>r2 >>r3;
    z = (volume(r1)+volume(r2)+volume(r3))/3;
    cout << "z = " << z << endl;
    return 0;
}
 */
 /*
#include <iostream>
#include <cmath> 
using namespace std;
float (float x)
{
    return pow (x,3)-pow (x,2)+x-1;
}
 int main()
 {
    float a,b,c,z;
    cout << "Введи 3 числа" << endl;
    cin >> ; >> a >> b >> c;
    z = f(2*a)+f(b+c);
    cout << "z=" << z << endl;
    return 0;
 }
 */
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 