/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>
#include <cmath>
using namespace std;

void func(float &x)
{
    x=(x>=0)?2*x: -x;
}
int main()
{
    float a;
    cout <<"Введите число ="; cin >> a;
    func(a); cout <<"a=" <<a << endl;

    return 0;
}*/


/*
#include <iostream>
#include <cmath>
using namespace std;

void func (float x, float &p,float &s)
{
    p=4*x;     s=x*x;
}

int main() 
{
    float a,p,s;
    cout <<"a="; cin>>a;
    func(a, p, s);
    (p>s)? cout << "Периметр": cout <<"Площадь";
    return 0;
}*/



//7. Разработать функцию f(x), которая возвращает вторую справа цифру натурального
//числа x. Вычислить с её помощью значение выражения z=f(a) + f(b) - f(c)


/*
#include <stdio.h>


int f(int n)
{
    return (n/10)%10;
}
 int main (int argc, char* argv[])
{
 int a,b,c;
 
 printf("a=");
 scanf("%d",&a);
 
 printf("b=");
 scanf("%d",&b);
 
 printf("c=");
 scanf("%d",&c);
 
 printf("f(%d)+f(%d)-f(%d)=%d\n", a,b,c,f(a)+f(b)-f(c));
}*/

8. Первая часть.
Вторая часть 17, 15

15.















    
    
    










