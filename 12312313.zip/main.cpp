/*
#include <iostream>
#include <math.h>
#include <iomanip>


using namespace std;

int main()
{
    int x; 
    float y;
    cout << "Введите число" << endl;
    cin >> x;
    y = (pow(x,2)+sin(x+1))/25;
    
    cout << "y= " << setprecision(5) << y << endl;
    
    return 0;
}*/

/*
#include <iostream>
#include <math.h>
#include <iomanip>


using namespace std;

int main()
{
    
    float s,p;
    cout << "Введи p" << endl;
    cin >> p;
    s = (pow(p/4,2));
    
    cout << "s= " << s << endl; 
    
    
    
    return 0;
    
    
}*/

/* Переделка
#include <iostream>


using namespace std;

int main()
{
    
    int x, y, z;
    cout << "Введите число" << endl;
    cin >> x;
    y= x/10;
    z= x - (x/10);
    ((y+z)%2 ==0) ? cout << "чётная" : cout << "нечётная" << endl;
    return 0;
}*/

/* 13 задание
#include <iostream>
#include <math.h>
#include <iomanip>


using namespace std;

int main()
{

    int a; 
    float b;
    cout << "Введите число" << endl;
    cin >> a;
    b = (pow(a,2)+pow(b,2))/ 1- (pow(a,3)-b)/3;
    
    cout << "b= " << setprecision(7) << b << endl;
    
    return 0;
}*/

/* 14 задание
#include <iostream>
#include <math.h>
#include <iomanip>


using namespace std;

int main()
{
    
    double x, y; 
    cout << "Введите число" << endl;
    cin >> x;
    y = (1+(pow(sin(x+y),2) / 2 + (fabs (x - (2 * x / 1+(pow(x,2)*pow(y,2))))))) +x;              
    
    cout << "y= " << setprecision(7) << y << endl;
    
    return 0;
}*/


/*
#include <iostream>
#include <math.h>
#include <iomanip>


using namespace std;

int main()
{
    
    double x, y; 
    cout << "Введите число" << endl;
    cin >> x;
    y = (0,125 * x + (abs (sin(x)) / 1,5*(pow(x,2)) + cos(x)));             
    
    cout << "y= " << setprecision(1) << y << endl;
    
    return 0;

}*/

/*
#include <iostream>
#include <math.h>
#include <iomanip>


using namespace std;

int main()
{

    int x; 
    float y;
    cout << "Введите число" << endl;
    cin >> x;
    y = x+y / x+1 - x*y-12 / 34 + x ;
    
    cout << "y= " << setprecision(7) << y << endl;
    
    return 0;
}*/

/*
   являеться ли , двухзначное число нечётной.
#include <iostream>
#include <math.h>
#include <iomanip>


using namespace std;

int main()
{
    
    int x, y, z;
    cout << "Введите число" << endl;
    cin >> x;
    y= x/10;
    z= x - (x/10);
    ((y+z)%2 ==0) ? cout << "Нечётная" : cout << "Чётная" << endl;
    return 0;
    
}*/









